import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class BitmapConvert<T> {

    public Image<T> readBitmapToArray(String filename, PixelConverter<T> converter) {
        try {
            File file = new File(filename);
            BufferedImage image = ImageIO.read(file);

            int width = image.getWidth();
            int height = image.getHeight();
            Image<T> pixelArray = new Image<T>(width, height);

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int pixel = image.getRGB(x, y);
                    int red = (pixel >> 16) & 0xff;
                    int green = (pixel >> 8) & 0xff;
                    int blue = pixel & 0xff;
                    T convertedPixel = converter.apply(red, green, blue);
                    pixelArray.getData()[y][x] = convertedPixel;
                }
            }
            return pixelArray;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void writeBitmapFromArray(String filename, Image<T> pixelArray) {
    	//TODO: Complete code [15 marks]
    }
       
}


