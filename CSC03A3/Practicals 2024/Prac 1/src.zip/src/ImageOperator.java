
public class ImageOperator<T> {
	private Image<T> img = new Image<T>(0, 0);
	
	
	/*
	 * A function that adds a scalar to every pixel in the Image
	 * returns transformed image
	 */
	public Image<T> addScalar(Image<T> img, int s){
		//TODO: Complete code [5 marks]
		return null;
	}
	
	/*
	 * A function that multiplies a scalar to every pixel in the Image
	 * returns transformed image
	 */
	public Image<T> multiplyScalar(Image<T> img, int s){
		//TODO: Complete code [5 marks]
		return null;
	}
	
	/*
	 * A function that flips / transposes the image 
	 * returns transformed image
	 */
	
	public Image<T> transpose(Image<T> img){
		//TODO: Complete code [5 marks]
		return null;
	}
	

}
