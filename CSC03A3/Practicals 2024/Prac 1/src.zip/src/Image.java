
class Image<T> {
    private T[][] data;
    private int width;
    private int height;

    public Image(int width, int height) {
        this.width = width;
        this.height = height;
        
    }
    
    private void instantiateArray(int height,int width) {
    	//TODO: Complete code [5 marks]
    }

    public T[][] getData() {
        return data;
    }

    public void setData(T[][] data) {
        this.data = data;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

}
