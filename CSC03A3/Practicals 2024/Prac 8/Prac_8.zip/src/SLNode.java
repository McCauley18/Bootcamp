
/**
 * A Skiplist Node
 * @param <E> The type of this node
 */
 //SLNODE CLASS TOTAL: 10 MARKS
public class SLNode<E> implements Position<E> {

	//TODO: COMPLETE - 10 MARKS 
 
	/*Data members: SLNodes for next,prev,above,below*/
	/*Data member element*/
		
    /**
     * Constructor for a new SLNode NB keep this ORDER for the parameters.
     * @param next the next link
     * @param prev the prev link
     * @param above the above link
     * @param below the below link
     * @param element the element
     */
  
    /**
     * Get the element for this Node
     * @return The element in this node
     */
	
    /*Accessor Methods */
  

    /*Update Methods*/
   

}
