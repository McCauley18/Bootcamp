package acsse.csc03a3;
//[15 marks correctness]
public class Main {
	/*
	 * a function that removes the first occurrence of an operator in the operatorList
	 */
	public List<String> removeOperatorFromList(String operator, List<String> operatorList){
		//TODO: Complete code [5 marks]
		return null;
	}
	
	/*
	 * a function that adds an operator to the end of the current operator list (duplicates are allowed)
	 */
	public List<String> addOperatorToList(String operator, List<String> operatorList){
		//TODO: Complete code [5 marks]
		return null;
	}
	/*
	 * A procedure for reading a Bitmap, apply all the operators in the operator List and 
	 * write the final bitmap to disk as output.bmp   
	 */
	public void processBitmapProcessList(String img, List<String> operatorList) {
		//TODO: Complete code [10 marks]
	}

	public static void main(String[] args) {
		boolean done=false;
		while (!done) {
			//TODO: Complete code [5 marks]
			//print options (view list, add operator to list, remove operator from list, process List or Exit)
			//loop for user based on command line input
			//Apply the appropriate function found above
			
		}

	}

}
