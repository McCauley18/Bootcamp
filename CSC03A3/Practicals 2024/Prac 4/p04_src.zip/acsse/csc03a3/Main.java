package acsse.csc03a3;
/*
 * Compilation and Correctness
 * (10 marks)
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Main extends Application {

	@Override
    public void start(Stage primaryStage) {
        // Initialize the UndoManager
        UndoManager undoManager = new UndoManager();

        // Create the TextArea and set its initial text
        /*
         * TextArea declaration
         * (3 marks)
         */
	//TODO: COMPLETE CODE HERE
   

	/*
	* Checks for undo keystroke and performs undo
	* (5 marks)
	*/
        //TODO: COMPLETE CODE HERE
        

        // Set an undo action on Ctrl+Z press
	/*
	* Checks for redo keystroke and performs redo
	* (10 marks)
	*/
        //TODO: COMPLETE CODE HERE
        
        /*
         * GUI setup and show
         * (7 marks)
         */
	//TODO: COMPLETE CODE HERE

    }

    public static void main(String[] args) {
        launch(args);
    }
}
