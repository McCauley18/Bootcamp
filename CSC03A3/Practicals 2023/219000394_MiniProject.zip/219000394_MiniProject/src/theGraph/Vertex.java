package theGraph;

public class Vertex<T> extends Graph.Vertex<PoliceStation> {

}
