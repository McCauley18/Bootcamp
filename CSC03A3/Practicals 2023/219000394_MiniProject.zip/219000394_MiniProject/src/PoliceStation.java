import java.util.ArrayList;

public class PoliceStation  implements Comparable<PoliceStation>{
	
	private String PoliceStationInformation;
	private int StatisticsForCrime;//  should be in % 
	private String PoliceStationName;
	private int NumofArrests ;
	private  double productivityRate ;
	
	public PoliceStation(String PoliceStationName, double productivityRate,String PoliceStationInformation, int StatisticsForCrime,int NumofArrests) { 
		// TODO Auto-generated constructor stub
		
		this.PoliceStationName = PoliceStationName;
		this.PoliceStationInformation = PoliceStationInformation;
		this.StatisticsForCrime = StatisticsForCrime;
		this.NumofArrests = NumofArrests;
	}

	
	//  getters and setters fort the PolicE station 
	public String getPolicStationName() {
		return PoliceStationName;	
	}
	 public void setPolicStationName(String PoliceStationName) {
		this.PoliceStationName =  PoliceStationName                                                         ;
	 }
	 
	 // getters and setters for the Statistic for Crime
	 
	 public double getproductivityRate() {
		  return productivityRate;
	 }
	 public void setproductivityRate(int productivityRate) {
		 this.productivityRate = productivityRate;
		 
	 }
	 
	 public int getStatisticsForCrime() {
		  return StatisticsForCrime;
	 }
	 public void setStatisticsForCrime(int StatisticsForCrime) {
		 this.StatisticsForCrime = StatisticsForCrime;
		 
	 }
	 public int getNumofArrests() {
		  return NumofArrests;
	 }
	 public void setNumofArrests(int NumofArrests) {
		 this.NumofArrests = NumofArrests;
		 
	 }
	 
	  // getter and setter for the Crime information 
	 public String getPoliceStationInformation() {
		return PoliceStationInformation;	 
	 }
	 
	 public void setPoliceStationInformation(String PoliceStationInformation) {
		  this.PoliceStationInformation = PoliceStationInformation;
	 }
	 
	 public void addPoliceStations (ArrayList<String> PoliceStationName) {
		 PoliceStationName.addAll(PoliceStationName);
	 }
        
	  public double calculateArrestRate() {
		  
		  int totalCrimes = getTotalCrimes() ;
		  int SuccessfulArrests = getNumofArrests();
		  
		  
		return (double) SuccessfulArrests /totalCrimes *100.0 ;
		  
	  }

	private int getTotalCrimes() {
		
		return 0;
	}


	@Override
	public int compareTo(PoliceStation o) {
		// TODO Auto-generated method stub
		
		return 0;
	}
	 
}
