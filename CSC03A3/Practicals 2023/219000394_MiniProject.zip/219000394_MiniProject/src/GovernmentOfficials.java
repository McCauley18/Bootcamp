import java.util.ArrayList;

public class GovernmentOfficials {
	
	private ArrayList<String>  GFnames ;
	private int RegNum ;
	private ArrayList<String>  Specialties ;
	

	public GovernmentOfficials(int RegNum) {
		// TODO Auto-generated constructor stub
		this.GFnames = new ArrayList<>();
		this.Specialties= new ArrayList<>();
		this.RegNum = RegNum;
	}
	
	public ArrayList<String> getSpecialties(){
		return Specialties;
	}
	public ArrayList<String> getGFnames(){
		return GFnames;
	}
	public int getRegNum() {
		return RegNum;
		
	}
	public void setRegNum(int RegNum ) {
		this.RegNum = RegNum;
	}
	public void setGFnames(ArrayList<String> GFnames ) {
		this.GFnames = GFnames;
	}
	public void setSpecialties(ArrayList<String> Specialties ) {
		this.Specialties = Specialties;
	}
	
	public void addGFnames(ArrayList<String> GFnames) {
		GFnames.addAll(getRegNum(), GFnames);
	}
	public void addSpecialties(ArrayList<String> Specialties) {
		Specialties.addAll(RegNum,Specialties );
	}
	
	public void removeGFnames(ArrayList<String> GFnames) {
		GFnames.remove(GFnames);
	}
	public void removeSpecialties(ArrayList<String> Specialties) {
		Specialties.remove(Specialties );
	}
	
}
