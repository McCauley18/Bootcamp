import java.util.Map;
import java.util.HashMap;

public class InformationAccess {
	
private Map<String ,PoliceStation> police_Stations;
private Map<String,AccessInfo> permitionForAccess;

public InformationAccess() {
	police_Stations = new HashMap<>();
	permitionForAccess = new HashMap<>();
	
}

public void addpoliceStations(PoliceStation policeStation) {
	police_Stations.put(policeStation.getPolicStationName(), policeStation);
	
}

public void AllowAcess(String PoliceStationName ,AccessInfo accessinfo ) {
	permitionForAccess.put(PoliceStationName, accessinfo);
	
}

public String getPoliceStationInformatio(String policeStationName, AccessInfo accessinfo) {
	
	PoliceStation policeStation = police_Stations.get(policeStationName);
	if (policeStation != null && Accesse(policeStation,accessinfo)) {
		
		return "Name: " +  policeStation.getPoliceStationInformation() + "\n" +
		       "CRIME INFORMATION :" + policeStation.getPoliceStationInformation() +
		       "CORRUPTION STATISTICS :" + policeStation.getStatisticsForCrime();
		
	} else {
		System.out.println("Access denied ");
	}
	return policeStationName;
	
}

// still need to edit 
private boolean Accesse(PoliceStation policeStation, AccessInfo accessinfo) {
	// TODO Auto-generated method stub
	AccessInfo onyRequiredAceess = permitionForAccess.get(policeStation);
	
	return false;
}
}
