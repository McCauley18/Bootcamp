import java.util.List;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import java.util.ArrayList; 
import javafx.scene.paint.Color;

public class InformationPane extends BorderPane {
	
private Button sendcomplainbt,sendReply , addPoliceStationsButton,RemovingPoliceStationButton, AddReportButton ,RemoveReportButton;
private  TextArea writeArea , writeArea2;
private	 TextField txtPoliceMemberName ;
private ComboBox<String> SelectPoliceStation ;
private List<Graph.Vertex<PoliceStation>> myVertices  = new ArrayList<Graph.Vertex<PoliceStation>>();
private List<Graph.Edge<PoliceStation>> myEdges = new ArrayList<Graph.Edge<PoliceStation>>();
private static Graph<PoliceStation> theGraph;
private List<String > vertexNames;
private List<String > vertexNames2;
boolean ifexists = false;
	

	public InformationPane(Community comminity , PoliceStation policeStation,LegalOrganisations legalOrganisation, GovernmentOfficials governmentOfficails ) {
		// TODO Auto-generated constructor stub
		
		
		Label ProgramTitle = new Label("POLICE ACCESS MANAGER");
		ProgramTitle.setStyle("-fx-font-size: 60px; -fx-font-weight: bold;");
		
				
		new Button("LEFT border pANE");
		new Button("right Border Pane");
		
	// BorderPane sections 
		 StackPane topPane = new StackPane(ProgramTitle);
		 topPane.setPadding(new Insets(5));
		Pane leftPane = MyLeftPane(comminity, policeStation);
		Pane CenterPane = MyCenterPane();
		Pane rightPane = MyRightPane();
		
		setTop(topPane);  topPane.setPrefSize(50, 80);
		setCenter(CenterPane);  CenterPane.setPrefSize(300, 100);
		setLeft(leftPane); leftPane.setPrefSize(200, 100);
		setRight(rightPane); rightPane.setPrefSize(300, 200);
		setSectionBorder(topPane,Color.DARKGRAY);
		setSectionBorder(rightPane,Color.DARKGRAY);
		setSectionBorder(leftPane,Color.DARKGRAY);
		setSectionBorder(CenterPane,Color.DARKGRAY);
		
		// adding vertexes
		addPoliceStationsButton.setOnAction (e ->{
		
			myEdges = theGraph.getEdges();
			myVertices = theGraph.getVertices();
			
			
     if(theGraph != null && (SelectPoliceStation.getValue() != null ) && !(txtPoliceMemberName.getText().equals("")) ){
    	 for(Graph.Vertex<PoliceStation> vertex :theGraph.getVertices() ) {
    		 if(SelectPoliceStation.getValue().equals(vertex.getValue().getPolicStationName())) {
    			 ifexists = true; break;
    			 
    		 }
    	 }
    	 
    	 if(!ifexists){
    		 int NumberofPiliceMemmbers = Integer.parseInt(txtPoliceMemberName.getText());
    		// List<String > vertexNames = new ArrayLists<>();
    		 theGraph.getVertices().set(NumberofPiliceMemmbers, null);
    		 for(Graph.Vertex<PoliceStation> vertex : theGraph.getVertices()) {
    			 vertexNames.add(vertex.getValue().getPolicStationName());
    			 
    		 }
    		 SelectPoliceStation.setItems(FXCollections.observableArrayList(vertexNames));
    		
    		 for (String name : vertexNames) {
    			 System.out.println(name);
    		 }
    		 for(Graph.Edge<PoliceStation> edge : theGraph.getEdges()) {
    			 
    			 vertexNames2.add("from this node :" + edge.getFromVertex().getValue().getPolicStationName() + "to :->" + edge.getToVertex().getEdges());
    		 }
    		 
    		 Alert alerts = new Alert(Alert.AlertType.INFORMATION);
    		 alerts.setContentText("Poice Station  was added successfully") ;
    		 alerts.setTitle("Notifications ");
    		 alerts.showAndWait();
    		 
    	 } else {
    		 Alert alerts = new Alert(Alert.AlertType.ERROR);
    		 alerts.setContentText("Poice Station  was added already") ;
    		 alerts.setTitle("Notifications ");
    		 alerts.showAndWait();
    	 } 
			
		}else {
   		 Alert alerts = new Alert(Alert.AlertType.ERROR);
   		 alerts.setContentText("it's empty") ;
   		 alerts.setTitle("Error");
   		 alerts.showAndWait();
   	 }
			
		});
		
		// removing Vertices 
		RemovingPoliceStationButton.setOnAction(e->{
			String SelectedPoliceStation = SelectPoliceStation.getValue();
			for(Graph.Vertex<PoliceStation> vertex : theGraph.getVertices()) {
				if(SelectedPoliceStation.equals(vertex.getValue().getPolicStationName())) {
					ifexists = true; break;
				}
				
			} 
			if(ifexists) {
				Graph.Vertex<PoliceStation> VertexRemove = null;
				
				for (Graph.Vertex<PoliceStation> vertex : theGraph.getVertices()) {
					if(SelectedPoliceStation.equals(vertex.getValue().getPolicStationName())) {
						VertexRemove = vertex;
						break;
					}
				}
				if(VertexRemove != null) {
					theGraph.getVertices().remove(VertexRemove);
					
					for(Graph.Vertex<PoliceStation> vertex : theGraph.getVertices()) {
						vertexNames.add(vertex.getValue().getPolicStationName());
	
					}
					SelectPoliceStation.setItems(FXCollections.observableArrayList(vertexNames));
					
					for(Graph.Edge<PoliceStation> edge : theGraph.getEdges()) {
						vertexNames2.add("add from:" + edge.getFromVertex().getValue().getPolicStationName() + "To ->" + edge.getToVertex().getEdge(VertexRemove));

					}
					 Alert alerts = new Alert(Alert.AlertType.INFORMATION);
		    		 alerts.setContentText("Poice Station  was removeed successfully") ;
		    		 alerts.setTitle("Notifications ");
		    		 alerts.showAndWait();
				}else {
					Alert alerts = new Alert(Alert.AlertType.ERROR);
		    		 alerts.setContentText("Poice Station  was not removed ") ;
		    		 alerts.setTitle("Error ");
		    		 alerts.showAndWait();
				}
			}else {
				Alert alerts = new Alert(Alert.AlertType.ERROR);
	    		 alerts.setContentText("Poice Station does not exist") ;
	    		 alerts.setTitle("Error");
	    		 alerts.showAndWait();
			}
			
		
				
	
				
		});
		
	}

	
private VBox MyRightPane() {
		// TODO Auto-generated method stub
	    Label informationLabel = new Label("INFORMATION FOR THE PUBLIC");
	    informationLabel.setStyle("-fx-font-size: 16px;");
	    TextArea displayArea =  new TextArea();
	    displayArea.setPadding(new Insets(10));
	    Label displyLabel = new Label();
	    displayArea.setPrefSize( 200, 400);
	    
	    
	    
	    VBox vbox3 = new VBox(informationLabel,displayArea,displyLabel);
	    
	       
		return vbox3;
	}
private VBox MyCenterPane() {
		// TODO Auto-generated method stub
	 
	 Label writeInfoLabel = new Label("Write your Report or Complain");
	 writeArea = new TextArea();
	 writeArea2 = new TextArea();
	 writeArea.setPrefSize(100, 150);
	 writeArea.setPadding(new Insets(10));
	
	 
	 sendcomplainbt = new Button("Send");
	 sendReply = new Button("Send");
	// 
	 TitledPane replytxt = new TitledPane();
	 replytxt.setText("reply");
	 VBox vbox2 = new VBox(writeArea2,sendReply);
	 replytxt.setContent(vbox2);
	 replytxt.setExpanded(false);;
	 VBox  vbox =  new VBox(writeInfoLabel,writeArea,sendcomplainbt,replytxt);
	 vbox.setAlignment(Pos.TOP_LEFT);
	
		return vbox;
	}
// my left bORDERed Pane
	private VBox MyLeftPane(Community community,PoliceStation policStation) {

		
		// first Title for the community Members 
				TitledPane myTitle1 = new TitledPane();
				txtPoliceMemberName = new TextField();
				Label memberName = new Label("Member Name");
				memberName.setStyle("-fx-font-size: 16px;");
				
				
				
				// Community MemberList
			/*
			 * 	ListView<String>  memberList = new ListView<>();
				memberList.getItems().addAll(community.getCommunityMemberName());
				memberList.getSelectionModel().selectedItemProperty().addListener((isaac,Mafunye, Micheal) ->{
					txtComunityName2.setText(Mafunye);
					
				});
			 */
				
				// my combo box for selection community
				 ComboBox<String> SelectPoliceStation = new ComboBox<>();
				 SelectPoliceStation.getItems().addAll("TEMBISA POLICE STATION","BRIXTON POLICE STATION","IVORY_POLICE STATION");
				 SelectPoliceStation.setPromptText("Select PoliceStation");
				 myTitle1.setText(" Adding and removing vertices");
					myTitle1.setContent(memberName);
					myTitle1.setPrefWidth(160);;
					
					// My buttons for adding and removing vertices 
				   
				    RemovingPoliceStationButton = new Button ("remove PoliceStation");
				       


					// login button
				    addPoliceStationsButton = new Button("add PoliceStation ");
					new Label();
					VBox MyVbox1 = new VBox(memberName,txtPoliceMemberName,SelectPoliceStation ,addPoliceStationsButton,RemovingPoliceStationButton);
					MyVbox1.setAlignment(Pos.TOP_LEFT);
					MyVbox1.setSpacing(2);
					MyVbox1.setPrefWidth(150);
					myTitle1.setContent(MyVbox1);
					myTitle1.setExpanded(false);
				
				// my Police station vbox

					// Buttons for adding Reports and removing them
			     AddReportButton = new Button("add  Crime Reports");
			    RemoveReportButton = new Button("Remove unseccessful reports ");
			    
			    
			   ;
				VBox MyVbox2 = new VBox(AddReportButton,RemoveReportButton);
				MyVbox2.setAlignment(Pos.TOP_LEFT);
				MyVbox2.setPrefWidth(150);
				//policeSttxt.setPrefSize(150, 30);
				TitledPane MyTitle2 = new TitledPane();
				MyVbox2.setSpacing(2);
				MyTitle2.setText("Adding and Removing edges" );
				MyTitle2.setContent(MyVbox2);
				MyTitle2.setExpanded(false);
				
				
			    // My buttons  
			    
	              
			        Button myButton = new Button("Success Rate");
					VBox MyVbox3 = new VBox(myButton);
					MyVbox3.setAlignment(Pos.TOP_LEFT);
					MyVbox3.setPrefWidth(150);
					//policeSttxt.setPrefSize(150, 30);
					TitledPane MyTitle3 = new TitledPane();
					MyVbox3.setSpacing(5);
					MyTitle3.setText("Productivity" );
					MyTitle3.setContent(MyVbox3);
					MyTitle3.setExpanded(false);
				
					TitledPane myTitle4 = new TitledPane();
				    TextField policeRgNumbertxt = new TextField();
					TextField policeNameTxt = new TextField();
					Label policeNameLabl = new Label(" User");
					Label PedgeNumberlabl = new Label("  Communty,legal orgainisation or Government");
					myTitle4.setText(" Report or reply");
					myTitle4.setContent(policeNameLabl);
					myTitle4.setPrefWidth(150);
				   // LogIn Button
						Button LoginBtn2 = new Button("LogIn");
					// Vbox for the community
						VBox MyVbox4 = new VBox(policeNameLabl,policeNameTxt,PedgeNumberlabl ,policeRgNumbertxt, LoginBtn2);
						MyVbox4.setAlignment(Pos.TOP_LEFT);
						MyVbox4.setSpacing(2);
						MyVbox4.setPrefWidth(150);
						myTitle4.setContent(MyVbox4);
						myTitle4.setExpanded(false);
						
						
				// adding my titles to MyleftPane
				VBox MyleftVbox = new VBox(myTitle1,MyTitle2,MyTitle3,myTitle4);
				MyleftVbox.setPrefWidth(180);
				MyleftVbox.setAlignment(Pos.TOP_LEFT);
				MyleftVbox.setSpacing(10);
				
				
				return  MyleftVbox;
		
	}
	
	private void setSectionBorder(Pane topPane, Color blueviolet) {
		// TODO Auto-generated method stub
		
		BorderStroke borderStroke = new BorderStroke(blueviolet, BorderStrokeStyle.SOLID, null, BorderStroke.THIN);
		topPane.setBorder(new Border(borderStroke));
	}
	
	

}
