import java.util.ArrayList;

public class Community {
	   
	private ArrayList<String> communityName ;
	
	private ArrayList<String>  communityMemberName;
	

	public Community(String CummunityIssues) {
		// TODO Auto-generated constructor stub
		this.communityName = new ArrayList<>();
		this.communityMemberName = new ArrayList<>();
		
	}
	public ArrayList<String> getCommunityName(){
		return communityName;
		
	}

	
	public ArrayList<String> getCommunityMemberName() {
		return communityMemberName;
	}
	
	public void setCommunityName(ArrayList<String> communityName) {
		this.communityName =  communityName;
	}
	
	
	public void setCommunityMemberName (ArrayList<String> communityMemberName) {
		this.communityMemberName = communityMemberName;
	}
	
	public void addCommunityNames(ArrayList<String> communityName) {
		communityName.addAll(communityName);
	}
	public void addSpecialties(ArrayList<String> Specialties) {
		Specialties.addAll(Specialties );
	}
	
	public void removeCommunityName(ArrayList<String> communityName) {
		communityName.remove(communityName);
	}
	public void removeCommunityMemberName(ArrayList<String> communityMemberName) {
		communityMemberName.remove(communityMemberName );
	}
	
	
	


}
