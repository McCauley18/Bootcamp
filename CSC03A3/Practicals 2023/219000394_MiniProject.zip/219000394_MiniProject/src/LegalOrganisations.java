
public class LegalOrganisations {
	
	private String OrganisationName;
	private String Resources ;

	public LegalOrganisations(String OrganisationName, String Resources) {
		// TODO Auto-generated constructor stub
		this.OrganisationName = OrganisationName;
		this.Resources = Resources;
	}
	
	public String getOrganisationName() {
		return OrganisationName;
		
	}

	public String getResources() {
		return Resources;
		
	}
	
	public void setOrganisationName(String OrganisationName) {
		this.OrganisationName = OrganisationName;
	}
	public void setResources(String Resources) {
		this.Resources = Resources;
	}
	
	public String toString() {
		return "Legal Organisation name :  "+ OrganisationName+ "\n" +
	
	                                      "Resources for the Organisation:" + Resources;
				
	}
}
