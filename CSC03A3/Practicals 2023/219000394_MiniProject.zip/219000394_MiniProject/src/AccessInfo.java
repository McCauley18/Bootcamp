
public enum AccessInfo {
   
	GOVERN_MENT,
	LEGALORGANIZATION,
	COMMUNITY
	
	
}
