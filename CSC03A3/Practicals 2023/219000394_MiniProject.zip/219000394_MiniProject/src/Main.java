import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main extends Application{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		InformationPane myRoot = new InformationPane(null, null, null, null);
		Scene scene = new Scene(myRoot, 800,499);
		//Scene scene = new Scene(root,800,500);
		primaryStage.setScene(scene);
		
		//primaryStage.setScene(scene);
		
		primaryStage.show();
		primaryStage.setTitle("Information Link");
		
	}

}
